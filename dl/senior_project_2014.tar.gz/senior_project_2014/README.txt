Benjamin Wicks Senior Project for BIOI 4980

I.	About my project:

	The project involved the creation of a new, custom online tool that enables
	evolutionary genetics students and researchers to closely and quickly
	perform phylogeny experiments comparing mitochondrial genomes of
	any combination of thousands of Metazoan species.

II.	How to use my source code:

	The *.php files present in the /web/ directory are intended to be placed in
	the /var/www/ directory of a machine with apache2 and php5 installed.

	The *.py scripts present in the /local/ directory are meant to be run from
	the command line.

	To begin the project from scratch:
