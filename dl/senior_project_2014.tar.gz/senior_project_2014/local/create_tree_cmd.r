id = commandArgs()[6]
pathIN <- '/home/stu14/BIOI_4980/clustalwOUT/'
pathOUT <- '/var/www/stu14/images/'
library(ape)
my_tree <- read.tree(paste(pathIN,id,".dnd",sep=""))
jpeg(paste(pathOUT,id,".jpg",sep=""))
plot(my_tree)
dev.off()
