from Bio import SeqIO
import os, os.path
import urllib2
import xml.etree.ElementTree as ET

#Mitogenome directory
mitoDir = '/home/stu14/BIOI_4980/mitogenomes/'

#NCBI base URL
eUtilsURL = 'http://eutils.ncbi.nlm.nih.gov/entrez/eutils/'
#esearch
searchURL = 'esearch.fcgi?db=taxonomy&term='
#efetch
fetchURL = 'efetch.fcgi?db=taxonomy&id='

found = []
notFound = []

for root, _, files in os.walk(mitoDir):
	for fn in files:
		fIn = open(mitoDir+fn,'rU')
		for record in SeqIO.parse(fIn, 'fasta'):
			species = record.description.split('|')[-1]
			species = species.split('mito')[0]
			#What if species contains 'isolate', 'complete', or 'voucher'?
			if ('isolate' in species):
				species = species.split('isolate')[0]
			elif ('complete' in species):
				species = species.split('complete')[0]
			elif ('voucher' in species):
				species = species.split('voucher')[0]
			#Species
			species = species.strip()
			#Accession Number
			accNum = fn.split('.')[-2]
			url1 = eUtilsURL+searchURL+species.replace(' ','%20')
			response1 = urllib2.urlopen(url1)
			responseStr1 = response1.read()
			root1 = ET.fromstring(responseStr1)
			for child1 in root1:
				if child1.tag == 'IdList':
					if len(child1) == 0:
						notFound.append((accNum,species))
					for c1 in child1:
						#Taxonomy ID
						taxID = c1.text
						print '=='+species+'=='
						print '\tAcc Num:\t\t'+accNum
						print '\tTax ID:\t\t\t' + taxID
						url2 = eUtilsURL+fetchURL+taxID
						response2 = urllib2.urlopen(url2)
						responseStr2 = response2.read()
						root2 = ET.fromstring(responseStr2)
						taxon = root2[0]
						#Reset all variables
						sciName = ''
						commonName = ''
						division = ''
						mitoCodeID = ''
						superKingdom = ''
						kingdom = ''
						phylum = ''
						subPhylum = ''
						superClass = ''
						regClass = ''
						superOrder = ''
						subOrder = ''
						infraOrder = ''
						family = ''
						subFamily = ''
						genus = ''
						subSpecies = ''
						for tag in taxon:
							if tag.tag == 'ScientificName':
								#Scientific Name
								sciName = taxon[1].text
							elif tag.tag == 'OtherNames':
								otherNames = taxon[2]
								#Common Name
								for oN in otherNames:
									if oN.tag == 'GenbankCommonName':
										commonName = oN.text
							elif tag.tag == 'Division':
								#Division
								division = taxon[5].text
							elif tag.tag == 'MitoGeneticCode':
								#Mitochondrial Genetic Code
								mitoCodeID = ''
							elif tag.tag == 'LineageEx':
								for tax in tag:
									if tax[2].text == 'superkingdom':
										superKingdom = tax[1].text
									elif tax[2].text == 'kingdom':
										kingdom = tax[1].text
									elif tax[2].text == 'phylum':
										phylum = tax[1].text
									elif tax[2].text == 'subphylum':
										subPhylum = tax[1].text
									elif tax[2].text == 'superclass':
										superClass = tax[1].text
									elif tax[2].text == 'class':
										regClass = tax[1].text
									elif tax[2].text == 'superorder':
										superOrder = tax[1].text
									elif tax[2].text == 'suborder':
										subOrder = tax[1].text
									elif tax[2].text == 'infraorder':
										infraOrder = tax[1].text
									elif tax[2].text == 'family':
										family = tax[1].text
									elif tax[2].text == 'subfamily':
										subFamily = tax[1].text
									elif tax[2].text == 'genus':
										genus = tax[1].text
									elif tax[2].text == 'subspecies':
										subSpecies = tax[1].text
					
						#status = root2[0][1].text
						#rank = root2[0][2].text
						#division = root2[0][3].text
						#scientificName = root2[0][4].text
						#commonName = root2[0][5].text
						#genus = root2[0][8].text
						#species = root2[0][9].text
						#subSp = root2[0][10].text
						#if (status is not None):
							#print '\tStatus:\t\t\t'+status
						#if (rank is not None):
							#print '\tRank:\t\t\t'+rank
						#if (division is not None):
							#print '\tDivision:\t\t'+division
						#if (scientificName is not None):
							#print '\tScientific name:\t'+scientificName
						#if (commonName is not None):
							#print '\tCommon name:\t\t'+commonName
						#if (genus is not None):
							#print '\tGenus:\t\t\t'+genus
						#if (species is not None):
							#print '\tSpecies:\t\t'+species
						#if (subSp is not None):
							#print '\tSub-species:\t\t'+subSp
						#found.append((accNum,taxID,status,rank,division,scientificName,commonName,genus,species,subSp))
						found.append((accNum,taxID,sciName,commonName,division,superKingdom,kingdom,phylum,subPhylum,superClass,regClass,superOrder,subOrder,infraOrder,family,subFamily,genus,subSpecies))
		fIn.close()

print 'Found taxonomy information for ' + str(len(found)) + ' files'
print 'Did NOT find taxonomy info for ' + str(len(notFound)) + ' files'
fOutFound = open('found.txt','w')
for f in found:
	line = ''
	for part in f:
		if (part is None):
			part = '\N'
		line = line + part + '\t'
	line = line.strip() + '\n'
	fOutFound.write(line)
fOutFound.close()
fOutNotFound = open('notFound.txt','w')
for n in notFound:
	fOutNotFound.write(n[0]+'\t'+n[1])
	fOutNotFound.write('\n')
fOutNotFound.close()
