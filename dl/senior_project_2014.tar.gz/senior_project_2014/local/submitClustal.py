#!/sur/bin/env python
import sys, os
import MySQLdb
import shutil
import time
from Bio import AlignIO
from Bio.Align.Applications import ClustalwCommandline
from subprocess import Popen, PIPE, STDOUT, call

#from Bio import Phylo

if (len(sys.argv) > 1):
	jobName = sys.argv[1]
	fnLog = '/home/stu14/BIOI_4980/clustalwOUT/'+jobName+'.log'
	fLog = open(fnLog,'w')
	fOutALN = '/home/stu14/BIOI_4980/clustalwOUT/'+jobName+'.aln'
	fOutDND = '/home/stu14/BIOI_4980/clustalwOUT/'+jobName+'.dnd'
	fIn = '/home/stu14/BIOI_4980/clustalwIN/'+jobName+'.fna'

	p = Popen(['clustalw','-type=dna','-infile='+fIn,'-outfile='+fOutALN,'-newtree='+fOutDND, '-align=True'],stdout=PIPE,stderr=STDOUT)
	for line in iter(p.stdout.readline,''):
		fLog.write(line)
		fLog.close()
		fLog = open(fnLog,'a')
		if not line:
			break

	fLog.close()

	db = MySQLdb.connect(host="localhost",user="stu14",passwd="mitogenome",db="geno_compare")	
	cur = db.cursor()

	#Query for jobID
	jobID = ''
	cur.execute("SELECT id FROM jobs WHERE name="+jobName)
	for row in cur.fetchall():
		jobID = row[0]

	#update SQL job entry
	cur.execute("UPDATE jobs SET status=1, start_time=NOW() WHERE id="+str(jobID))

	#start R job
	fLog = open(fnLog,'a')
	p = Popen(['Rscript','/home/stu14/BIOI_4980/scripts/create_tree_cmd.r',jobName],stdout=PIPE,stderr=STDOUT)
	for line in iter(p.stdout.readline,''):
		fLog.write(line)
		fLog.close()
		fLog = open(fnLog,'a')
		if not line:
			break
	fLog.close()
#	call(['Rscript','/home/stu14/BIOI_4980/scripts/create_tree_cmd.r',jobName],stdout=stdOUT,stderr=stdERR)

	#update SQL job entry again
	cur.execute("UPDATE jobs SET status=5 WHERE id="+str(jobID))

	#chmod the new image file
	os.chmod('/var/www/stu14/images/'+jobName+'.jpg',0777)

	#Move the aln and dnd files to /var/www/stu14/aln/
	shutil.copy('/home/stu14/BIOI_4980/clustalwOUT/'+jobName+'.aln','/var/www/stu14/aln/'+jobName+'.aln')
	os.chmod('/var/www/stu14/aln/'+jobName+'.aln',0777)
	shutil.copy('/home/stu14/BIOI_4980/clustalwOUT/'+jobName+'.dnd','/var/www/stu14/aln/'+jobName+'.dnd')
	os.chmod('/var/www/stu14/aln/'+jobName+'.dnd',0777)

	fLog = open(fnLog,'a')
	fLog.write("LAST STEP!")
	fLog.close()

	#update SQL job entry again
	cur.execute("UPDATE jobs SET status=10, finish_time=NOW() WHERE id="+str(jobID))
	db.close()
	#Parse Newick tree file
	#tree = Phylo.read('/home/stu14/BIOI_4980/clustalwIN/'+jobName+'.dnd','newick')
	#Phylo.draw_ascii(tree)
	#Phylo.draw_graphiz(tree)
else:
	print 'No job name provided.'
