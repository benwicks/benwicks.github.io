<?php
error_reporting(E_ALL);
if (isset($_POST['list2'])) {
	$list = $_POST['list2'];
	#First, check to see if this job has ever been run before
	$query1 = 'SELECT DISTINCT job_id FROM species_in_jobs WHERE job_id = ANY (SELECT DISTINCT job_id FROM species_in_jobs WHERE acc_num IN (\'';
	foreach ($list as &$l) {
		$query1 .= $l . '\',\'';
	}
	unset($l);
	$query1 = substr($query1, 0, -2) . ')) ORDER BY job_id';
	#echo '<h2>First query: '.$query1.'</h2>';
	$mysqli = mysqli_connect("localhost","stu14","mitogenome","geno_compare") or die("Some error occurred during connection " . mysqli_error($mysqli));
	if (!$mysqli) {
		die('Connect error ('.mysqli_connect_errno().'): '.mysqli_connect_error());
	}
	$result = mysqli_query($mysqli, $query1) or die(mysqli_error());
	if ($result) {
		while($row=mysqli_fetch_array($result)) {
			$jobID = $row['job_id'];
			$query2 = 'SELECT acc_num FROM species_in_jobs WHERE job_id = \''.$jobID.'\'';
			#echo '<h3>Next query: '.$query2.'</h3>';
			$result2 = mysqli_query($mysqli, $query2) or die(mysqli_error());
			if ($result2) {
				if ($result2->num_rows != count($list)) {
					$allDone = False;
					continue;
				} else {
					while ($row2=mysqli_fetch_array($result2)) {
						$acc_num = $row2['acc_num'];
						if (in_array($acc_num,$list)) {
							continue;
						} else {
							#This previous experiment was not an exact match
							$allDone = False;
							break;
						}
					}
					#Found a matching previous experiment
					$allDone = True;
					break;
				}
			}
		}
	}
	mysqli_close($mysqli);
	if ($allDone) {
		#This job is a duplicate - refer to pre-existing match
		echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><title>Benjamin Wicks Senior Project</title></head><body><h1>Submit Experiment</h1>';
		echo '<h3>This experiment matches one that has been submitted previously so it will not continue. To see the status of the previous experiment, click <a href="/stu14/submit.php?job_id='.$jobID.'">here</a>.</h3>';
		echo '<hr />';
	} else {
		#This job is unique and new - begin a new job!
		$allSequences = '';
		$mysqli = mysqli_connect("localhost","stu14","mitogenome","geno_compare") or die("Some error occurred during connection " . mysqli_error($mysqli));
		if (!$mysqli) {
			die('Connect error ('.mysqli_connect_errno().'): '.mysqli_connect_error());
		}
		foreach ($list as &$l) {
			$seq = file_get_contents('/home/stu14/BIOI_4980/mitogenomes/'.$l.'.fna');
			$line1 = '>Species_Name...';
			#Get common name!
			$query = 'SELECT common_name, scientific_name FROM mito_taxonomy WHERE acc_num = \''.$l.'\'';
			$result = mysqli_query($mysqli, $query) or die(mysqli_error());
			if ($result) {
				$row=mysqli_fetch_array($result);
				$cName = $row['common_name'];
				$sName = $row['scientific_name'];
				$name = '';
				if (strlen($cName) == 0) {
					$name = str_replace(' ','_',$sName);
				} else {
					$sName = $sName.' {'.$cName.'}';
					$name = str_replace(' ','_',$sName);
				}
				$line1 = '>'.$l.'_['.$name.']';
			}
			#TODO: perhaps create a small graph showing the number of characters in each sequence??
			#echo 'Sequence ('.$l.') has '.strlen($seq).' characters.';
			#echo '<br />';
			if ($seq === false) {
				// error reading file
				#TODO: Save this and print it somewhere else?
				echo '<p style="color:red;"><b>ERROR READING FILE: '.$l.'.fna</b></p>';
			} else {
				$lines = explode("\n", $seq);	
				$seq = $line1."\n".implode("\n",array_slice($lines,1));
				$allSequences .= $seq;
			}
		}
		unset($l);
		mysqli_close($mysqli);
		#Create the input file for clustalW
		#(and allow for multiple submissions at (near) the exact same time.)
		$now = time();
		$fn = '/home/stu14/BIOI_4980/clustalwIN/'.$now.'.fna';
		$attempt = 1;
		while (file_exists($fn)) {
			$now = $now.'_'.$attempt;
			$fn = '/home/stu14/BIOI_4980/clustalwIN/'.$now.'.fna';
			$attempt = $attempt + 1;
		}
		$fOut = file_put_contents($fn, $allSequences);
		#Insert this job into a database and mark it as running
		if ($fOut) {
			$mysqli = mysqli_connect("localhost","stu14","mitogenome","geno_compare") or die("Some error occurred during connection " . mysqli_error($mysqli));

			if (!$mysqli) {
				die('Connect error ('.mysqli_connect_errno().'): '.mysqli_connect_error());
			}
			#Insert this job into the database
			$my_data=mysqli_real_escape_string($mysqli, $q);
			$sql="INSERT INTO jobs (name, status) VALUES (".$now.", 0)";
			mysqli_query($mysqli, $sql) or die(mysqli_error());
			$jobID = mysqli_insert_id($mysqli);
			$insertStatement2 = 'INSERT INTO species_in_jobs VALUES ';
			foreach ($list as &$l) {
				$insertStatement2 .= '("'.$l.'",'.'"'.$jobID.'"),';
			}
			unset($l);
			#Trim last comma off
			$insertStatement2 = rtrim($insertStatement2,',');
			#echo '<h2>SQL: '.$insertStatement2.'</h2>';
			mysqli_query($mysqli, $insertStatement2) or die(mysqli_error());
			mysqli_close($mysqli);

			#Start python job
			$command = 'python /home/stu14/BIOI_4980/scripts/submitClustal.py '.$now.' > /dev/null 2>/dev/null &';
			#print '<h2>Command: '.$command.'</h2>';
			header('Refresh: 10; URL=/stu14/submit.php?job_id='.$jobID);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Benjamin Wicks Senior Project</title>
</head>
<body>
<h1>Submit experiment</h1>
<?php
			echo '<h2>Congratulations, you have submitted a unique job comparing the mitochondrial genomes of '.count($list).' species</h2>';
			echo '<h2>Your job is in progress. Wait 10 seconds for the page to refresh for more information.</h2>';
			$output = shell_exec($command);
			echo $output;
			echo '<hr />';
		} else {
			echo '<h1>Error in writing '.count($list).' sequences to '.$now.'.fna</h1>';
		}
	}
} else if (isset($_GET['job_id'])) {
	$jobID = $_GET['job_id'];
	$mysqli = mysqli_connect("localhost","stu14","mitogenome","geno_compare") or die("Some error occurred during connection " . mysqli_error($mysqli));
	if (!$mysqli) {
		die('Connect error ('.mysqli_connect_errno().'): '.mysqli_connect_error());
	}
	$query = 'SELECT status, name FROM jobs WHERE id = \''.$jobID.'\'';
	$result = mysqli_query($mysqli, $query) or die(mysqli_error());
	if ($result->num_rows > 0) {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Benjamin Wicks Senior Project</title>
</head>
<body>
<h1>Submit experiment</h1>
<?php
		$row=mysqli_fetch_array($result);
		$status = $row['status'];
		$name = $row['name'];
		if ($status < 0) {
			#This job has been permanently saved. Provide link to relevant stats page.
			echo '<h3></h3>';
		} else if ($status == 10) {
			echo '<h3>Congratulations! Your job is complete.</h3>';
			#Show output!
			echo '<img src="images/'.$name.'.jpg">';
			echo '<p>This is an image that was created for your experiment. The alignment file can be downloaded <a href="aln/'.$name.'.aln">here</a> and the dendogram file can be downloaded <a href="aln/'.$name.'.dnd">here</a>.</p>';
			#Implement save experiment functionality!
			echo '<form name="f2" action="statistics.php?job_id='.$jobID.'" method="post">';
			echo '<label>Name your experiment:</label>';
			echo '<input name="name" type="text" id="name" size="40" value="'.$name.'" />';
			echo '<label>Provide a description:</label>';
			echo '<input name="description" type="text" id="description" size="40" />';
			echo '<input type="hidden" name="id" value="'.$jobID.'" />';
			echo '<input type="hidden" name="oldName" value="'.$name.'" />';
			echo '<br />';
			echo '<input id="saveBtn" type="submit" name="save" value="Save experiment" />';
			echo '</form>';
		} else {
			#This job is in progress. Provide an estimation and refresh page.
			echo '<h3>Continuing to process experiment '.$jobID.'</h3>';
			if ($status == 1) {
				echo '<h4>The CLUSTALW step has completed!</h4>';
			} else if ($status == 5) {
				echo '<h4>The R step has completed!</h4>';
			}
			echo '<h4>Wait for refresh in 10 seconds</h4>';
			header('Refresh: 10; URL=/stu14/submit.php?job_id='.$jobID);
		}
	} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Benjamin Wicks Senior Project</title>
</head>
<body>
<h1>Submit experiment</h1>
<?php
		echo '<h2>This job does not exist in the database. Sorry - jobs are deleted after a week if they are not saved! You can begin a new experiment <a href="/stu14/">here</a>.</h2>';
	}
} else {
	echo '<h2>You did not submit an experiment - perhaps you came to this page by accident. Go <a href="/stu14/">here</a> to submit an experiment.</h2>';
}
?>
</body>
</html>
