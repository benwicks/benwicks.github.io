<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"
[
  <!ATTLIST tag taxID CDATA #IMPLIED&gt;
]>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Benjamin Wicks Senior Project</title>
<script type="text/javascript" src="jquery.js"></script>
<script>
$(document).ready(function() {
	document.getElementById("ltr").onclick=function() {
		var l1 = document.getElementById("list1");
		var l2 = document.getElementById("list2");
		var toAdd = new Array();
		var idx = 0;
		for (var i = l1.length - 1; i >= 0; i--) {
			var opt = l1.options[i];
			if (opt.selected) {
				toAdd[idx] = opt;
				idx = idx + 1;
				l1.remove(i);
				// console.log('removed '+i);
			}
		}
		if (toAdd.length > 0) {
			for (var i = toAdd.length - 1; i >= 0; i--) {
				l2.add(toAdd[i]);
			}
			list1Change();
			list2Change();
		}
	};
	document.getElementById("rtl").onclick=function() {
		var l1 = document.getElementById("list1");
		var l2 = document.getElementById("list2");
		var opt = l2.options[l2.selectedIndex];
		if (typeof opt != 'undefined') {
			var idx = opt.id;
			l1.add(opt,l1[idx]);
			// console.log("Replaced Index: "+idx);
			l2.remove(l2.selectedIndex);
			list1Change();
			list2Change();
		}
	};
});

$(function() {
	var select1 = $("#list1");
	var select2 = $("#list2");
	var in1 = $("#filter");
	var options = select1.find("option").clone();

	function cleanText(string) {
		return $.trim(string).replace(/\s+/g, ' ').toLowerCase();
	}

	options.each(function() {
		var option = $(this);
		option.data("cleaned",cleanText(option.text()));
	});

	in1.bind("keyup", function (event) {
		var term = cleanText($(this).val());
		var options2 = [];
		select2.find("option").each(function() {
			options2.push($(this).text());
		});
		var matches;
		
		if (!term) {
			if (options2.length == 0) {
				select1.empty().append(options.clone());
				return;
			} else {
				matches = jQuery.grep(options, function(value, index) {
					var option = value.text;
					var pos = jQuery.inArray(option, options2);
					return pos === -1;
				});
				select1.empty().append(matches);
				return;
			}
		}

		matches = options.filter(function() {
			return $(this).data("cleaned").indexOf(term) != -1;
		}).clone();

		if (options2.length > 0) {
			matches = jQuery.grep(matches, function(value, index) {
				var option = value.text;
				var pos = jQuery.inArray(option, options2);
				//if (pos >= 0) {
					//matches.splice(index, 1);
				//}
				return pos === -1;
			});
		}

		select1.empty().append(matches);
	});
});

function list1Change() {
	var l1 = document.getElementById("list1");
	var suggest1 = document.getElementById("suggestion1");
	var text = '';
	var counter = 0;
	for (var i = 0; i < l1.length; i++) {
		var opt = l1.options[i];
		if (opt.selected) {
			// Suggest a link to the ncbi taxonomy listing
			if (counter > 0) {
				text += '<br />';
			}
			text += 'Learn more about <a href="http://www.ncbi.nlm.nih.gov/Taxonomy/Browser/wwwtax.cgi?id='+opt.getAttribute('taxID')+'" target="_blank">'+opt.text+'</a>';
			counter = counter + 1;
		}
		if (counter > 0) {
			suggest1.innerHTML = text;
		} else {
			var l2 = document.getElementById("list2");
			if (l2.length > 0) {
				suggest1.innerHTML = 'You may select another species';
			} else {
				suggest1.innerHTML = 'Select your first species';
			}
		}
	}
	if (l1.length == 0) {
		suggest1.innerHTML = 'Refine your filter query';
	}
}

function list2Change() {
	var l2 = document.getElementById("list2");
	var opt = l2.options[l2.selectedIndex];
	if (typeof opt != 'undefined') {
		// TODO: Formulate suggestion
		suggestP = document.getElementById("suggestion2");
		// console.log('TaxID: '+opt.getAttribute('taxID'));
		suggestP.innerHTML = 'Something related to '+opt.text;
	} else {
		suggestP = document.getElementById("suggestion2");
		if (l2.length == 0) {
			suggestP.innerHTML = 'Select your first species';
		} else if (l2.length < 3) {
			suggestP.innerHTML = 'Please select another species';
		} else {
			suggestP.innerHTML = 'Select another species or submit your experiment';
		}
	}
	if (l2.length > 2) {
		document.getElementById("submitBtn").disabled = false;
	} else {
		document.getElementById("submitBtn").disabled = true;
	}
};

function selectAll() {
	selectBox = document.getElementById("list2");
	selectBox.multiple = true;
	for (var i = 0; i < selectBox.options.length; i++) {
		selectBox.options[i].selected = true;
	}
	return true;
}
</script>
</head>
<body>
<h1>Comparative Mitogenomics among Metazoan Species</h1>
<h2>About</h2>
<p>This tool allows users to study phylogenetic relationships among the thousands of metazoan (subset of animal kingdom excluding sponges) mitochondrial genomes available from <a href="ftp://ftp.ncbi.nlm.nih.gov/genomes/MITOCHONDRIA/Metazoa/" target="_blank">NCBI's FTP site</a>.</p>
<p>The evolutionary phylogenetic relationships are calculated using the <a href="http://www.clustal.org/clustal2/" target="_blank">CLUSTALW</a> multiple sequence alignment tool and displayed using the <a href="http://evolution.genetics.washington.edu/phylip.html" target="_blank">phylip</a> software package.</p>
<p>To view statistics and more about previous experiments, go to the <a href="statistics.php">statistics page</a>.</p>
<p>The source code is available at my subversion repository <a href="https://clabsvn.ist.unomaha.edu/svn/user/bwicks/" target="_blank">here</a>.</p>
<h2>Instructions:</h2>
<ul>
<li>To add a species to your experiment, choose it from the list on the left and click the "&gt;&gt;" button</li>
<li>Select at least three species from the list on the left</li>
<ul>
<li>Use suggestions that appear below the box on the right to continue adding species</li>
</ul>
<li>To remove a species from your experiment, click the "&lt;&lt;" button</li>
<li>Once you have added all the (3+) species you wish to investigate, click "Submit experiment"</li>
</ul>

<label>Filter list:</label>
<input name="filter" type="text" id="filter" size="40"/>
<br />
<br />
<form name="f1" action="submit.php" method="post" onsubmit="return selectAll();">
<div style="width:900px;height:200px;text-align:center;margin:0 auto;">
<div style="float:left;text-align:center;width:370px;height:200px;">
<?php
$mysqli = mysqli_connect("localhost","stu14","mitogenome","geno_compare") or die("Some error occurred during connection " . mysqli_error($mysqli));

if (!$mysqli) {
        die('Connect error ('.mysqli_connect_errno().'): '.mysqli_connect_error());
}

$my_data=mysqli_real_escape_string($mysqli, $q);
$sql="SELECT * FROM mito_taxonomy WHERE acc_num != '' GROUP BY scientific_name ORDER BY scientific_name";
// TODO: include all data in option tag (division, super_kingdom, kingdom, phylum, sub_phylum, super_class, class, super_order, sub_order, infra_order, family, sub_family, genus, sub_species)
$result = mysqli_query($mysqli,$sql) or die(mysqli_error());

$numRows = $result->num_rows;
echo '<label>All species:</label>';
echo '<br />';
echo '<select id="list1" size="10" style="width:360px" multiple onchange="list1Change();">';

if($result) {
	$num = 0;
        while($row=mysqli_fetch_array($result)) {
		echo '<option id="'.$num.'" value="'.$row['acc_num'].'" taxID="'.$row['tax_id'].'">'.$row['scientific_name'];
		if (strlen($row['common_name']) > 0) {
			echo ' ('.$row['common_name'].')';
		}
		echo '</option>';
		$num = $num + 1;
        }
}
mysqli_close($mysqli);
?>
</select>
<p id="suggestion1">Select your first species</p>
</div>
<div style="position:relative;margin:0 auto;display:inline-block;height:200px;width:50px;">
<div style="position:absolute;top:50%;height:100px;margin-top:-50px;width:100%">
<button type="button" id="ltr">&gt;&gt;</button>
<br />
<button type="button" id="rtl">&lt;&lt;</button>
</div>
</div>
<div style="float:right;text-align:center;width:370px;height:200px;">
<label>Your experiment's species:</label>
<select name="list2[]" id="list2" size="10" style="width:360px" onchange="list2Change();">
</select>
<p id="suggestion2"></p>
</div>
</div>
<br />
<div style="text-align:center;">
<input id="submitBtn" type="submit" name="submit" value="Submit experiment" disabled />
</div>
</form>
</body>
</html>
