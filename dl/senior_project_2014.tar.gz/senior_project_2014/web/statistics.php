<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>Statistics</title>
</head>
<body>
<h1>Statistics</h1>
<h2>Saved Experiments</h2>
<script type="text/javascript" src="jquery.js"></script>
<script>
function list1Change() {
	var l1 = document.getElementById("list1");
	var text = '';
	var opt = l1.options[l1.selectedIndex];
	var jobDiv = document.getElementById("jobDiv");
	text = '<h3>'+opt.text+'</h3>';
	var description = opt.getAttribute('description');
	var more = opt.getAttribute('more');
	var name = opt.text.split(' ').join('_');
	text += '<img src="images/'+name+'.jpg" alt="" >';
	text += '<p>'+description+'</p>';
	text += '<p>'+more+'</p>';
	text += '<p>The alignment file can be downloaded <a href="aln/'+name+'.aln">here</a> and the dendogram file can be downloaded <a href="aln/'+name+'.dnd">here</a>.</p>';

	jobDiv.innerHTML = text;
}
</script>
<?php
if (isset($_POST['save'])) {
	$jobID = $_POST['id'];
	$oldName = $_POST['oldName'];
	$newName = $_POST['name'];
	$description = $_POST['description'];
	$mysqli = mysqli_connect("localhost","stu14","mitogenome","geno_compare") or die("Some error occurred during connection " . mysqli_error($mysqli));
	if (!$mysqli) {
		die('Connect error ('.mysqli_connect_errno().'): '.mysqli_connect_error());
	}
	$newName = mysqli_real_escape_string($mysqli, $newName);
	$newDescription = mysqli_real_escape_string($mysqli, $description);
	$query = 'UPDATE jobs SET status=-1, name="'.$newName.'", description="'.$newDescription.'" WHERE id = \''.$jobID.'\'';
	mysqli_query($mysqli, $query) or die(mysqli_error());
	#Also update filenames
	$newName = str_replace(' ','_',$newName);
	rename('/var/www/stu14/images/'.$oldName.'.jpg','/var/www/stu14/images/'.$newName.'.jpg');
	rename('/var/www/stu14/aln/'.$oldName.'.aln','/var/www/stu14/aln/'.$newName.'.aln');
	rename('/var/www/stu14/aln/'.$oldName.'.dnd','/var/www/stu14/aln/'.$newName.'.dnd');
	echo '<h3>Your experiment was named successfully.</h3>';
	mysqli_close($mysqli);
}
if (isset($_GET['job_id'])) {
	$jobID = $_GET['job_id'];
	$jobName = 'Job Name';
} else {
	$jobID = '';
}
#Query database for all saved jobs and populate a drop-down list
$mysqli = mysqli_connect("localhost","stu14","mitogenome","geno_compare") or die("some error occurred during connection " . mysqli_error($mysqli));
if (!$mysqli) {
        die('connect error ('.mysqli_connect_errno().'): '.mysqli_connect_error());
}
$sql="SELECT * FROM jobs WHERE status = 10 OR status = -1 ORDER BY finish_time";
$result = mysqli_query($mysqli,$sql) or die(mysqli_error());
$numRows = $result->num_rows;
echo '<p>There are '.$numRows.' complete experiments in the database.</p>';
echo '<label>All complete experiments:</label>';
echo '<br />';
echo '<select id="list1" onchange="list1Change();">';
if($result) {
        while($row=mysqli_fetch_array($result)) {
		$more = '';
		echo '<option id="'.$row['id'].'" value="'.$row['name'].'" more="'.$more.'" description="'.addslashes($row['description']).'" ';
		if ($row['id'] == $jobID) {
			#Set dropdown list to this id
			$jobName = $row['name'];
			echo 'selected';
		}
		echo '>'.$row['name'].'</option>';
	}
}
mysqli_close($mysqli);
echo '</select>';
echo '<div id="jobDiv">';
if (strlen($jobID) > 0) {	
	echo '<h3>'.$jobName.'</h3>';
	#Output image and links to alignments
	$jobName = str_replace(' ','_',$jobName);
	echo '<img src="images/'.$jobName.'.jpg" alt="">';
	echo '<p>'.$description.'</p>';
	#TODO: Calculate how long this job took
	$more = '';
	echo '<p>'.$more.'</p>';
	echo '<p>The alignment file can be downloaded <a href="aln/'.$jobName.'.aln">here</a> and the dendogram file can be downloaded <a href="aln/'.$jobName.'.dnd">here</a>.</p>';
} else {
?>
<h3>All Sharks</h3>
<img src="images/image1.jpg" alt="Phylogenetic tree from PHYLIP of all sharks" >
<p>This is an image that was created by comparing all 28 species that matched "shark." The alignment file can be downloaded <a href="aln/aln1.aln">here</a> and the dendogram file can be downloaded <a href="aln/aln1.dnd">here</a>.</p>
<?php
}
echo '</div>';
echo '<p>Click <a href="/stu14">here</a> to begin a new experiment</p>';
?>
</body>
</html>
